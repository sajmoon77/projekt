<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <center>
    <header><h1>Czytaj zawartość</h1></header>
    <fieldset>
    <?php
    $nazwa=$_POST['sciezka'];
    $plik=fopen("$nazwa", "a"); //otwarcie pliku
    $dane=$_POST['tekst'];   //zmienna z tekstem
    fwrite($plik, $dane."\n");   //wpisanie tekstu do pliku
    fclose($plik);          //zamkniecie pliku

    $plik=fopen("$nazwa", "r");
    //for($i=0; $i<10; $i++){
        //$tab[$i]=rand(10,20);
        //fwrite($plik, $tab[$i]."\n");
    //}
    while(!feof($plik)){
        echo fgets($plik)."<br>";
    }
    echo "Odczytywanie znak po znaku<br>";

    $plik=fopen("$nazwa", "r");
    $i=0;
    while(!feof($plik)){
        $liczba[$i]=fgetc($plik);
        echo $liczba[$i]."<br>";
        $i++;
    }
    fclose($plik);
    ?>

            </fieldset>
            <footer><h1>Autor: Szymon Ptaszek &copy;</h1></footer>
        </center>
</body>
</html>
