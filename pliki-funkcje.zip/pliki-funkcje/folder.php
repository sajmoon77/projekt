<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <center>
    <header><h1>Utworzenie folderu</h1></header>
    <fieldset>
    <?php
        $folder = $_POST['folder'];
        mkdir ("../pliki-funkcje/$folder", 0777);
        echo "<b>Folder o nazwie: <i>$folder</i> został stworzony!</b>";
?>
            </fieldset>
            <footer><h1>Autor: Szymon Ptaszek &copy;</h1></footer>
        </center>
</body>
</html>
