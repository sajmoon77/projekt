<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <center>
    <header><h1>Informacje o pliku</h1></header>
    <fieldset>
    <?php
        $plik=$_POST['sciezka'];
        echo "Czas unixowy utworzenia pliku: ".fileatime("$plik")."<br>";
        echo "Czas unixowy ostatniej modyfikacji pliku: ".filemtime("$plik")."<br>";
        echo "Id właściciela pliku: ".fileowner("$plik")."<br>";
        echo "Uprawnienia właściciela pliku: ".fileperms("$plik")."<br>";
        echo "Rozmiar pliku w bajtach: ".filesize("$plik")."<br>";
    ?>
    </fieldset>
            <footer><h1>Autor: Szymon Ptaszek &copy;</h1></footer>
        </center>
</body>
</html>

