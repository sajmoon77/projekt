<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <center>
    <header><h1>Funkcje na plikach</h1></header>
    <fieldset>
    <?php
    $tekst=$_POST['tekst'];
$nazwa=$_POST['sciezka'];
$plik = fopen("$nazwa", "a") or die("Nie da się utworzyć pliku");
$txt = $_POST['tekst'];
echo "Tekst: ".$tekst." został wpisany do pliku: ".$nazwa;
fwrite($plik, $txt."\n");

fclose($plik);

?>
    
            </fieldset>
            <footer><h1>Autor: Szymon Ptaszek &copy;</h1></footer>
        </center>
</body>
</html>

