<!DOCTYPE html>
<html lang="pl">
<head>
    <link rel="stylesheet" href="styl.css">
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <center>
    <header><h1>Funkcje na plikach</h1></header>
    <fieldset>
            
<?php
    $folder = $_POST['folder'];
    $katalog = "./$folder";
    $pliki = scandir($katalog);
    foreach($pliki as $plik) echo '<p>'.$plik.'</p>';
    ?>
            </fieldset>
            <footer><h1>Autor: Szymon Ptaszek &copy;</h1></footer>
        </center>
</body>
</html>


